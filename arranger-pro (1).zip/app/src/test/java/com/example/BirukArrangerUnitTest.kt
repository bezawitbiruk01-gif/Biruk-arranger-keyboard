package com.example

import com.example.audio.AudioEngine
import com.example.localization.AppLanguage
import com.example.localization.LocalizationManager
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test

class BirukArrangerUnitTest {

    @Test
    fun testExperienceLevels() {
        val levels = ExperienceLevel.values()
        assertEquals(3, levels.size)
        assertTrue(levels.contains(ExperienceLevel.BEGINNER))
        assertTrue(levels.contains(ExperienceLevel.INTERMEDIATE))
        assertTrue(levels.contains(ExperienceLevel.ADVANCED))

        // Check Amharic titles
        assertEquals("ጀማሪ", ExperienceLevel.BEGINNER.amharicTitle)
        assertEquals("መካከለኛ", ExperienceLevel.INTERMEDIATE.amharicTitle)
        assertEquals("ከፍተኛ / ፕሮፌሽናል", ExperienceLevel.ADVANCED.amharicTitle)
    }

    @Test
    fun testVelocityCurves() {
        // Test FIXED_FULL velocity mode always produces 1.0f
        assertEquals(1.0f, VelocityMode.FIXED_FULL.calculateVelocity(0.1f), 0.001f)
        assertEquals(1.0f, VelocityMode.FIXED_FULL.calculateVelocity(0.9f), 0.001f)

        // Test SOFT velocity mode
        val softVal = VelocityMode.SOFT.calculateVelocity(0.5f)
        assertTrue("Soft velocity at 0.5 should be >= 0.7f, was $softVal", softVal >= 0.7f)

        // Test HARD velocity mode
        val hardVal = VelocityMode.HARD.calculateVelocity(0.5f)
        assertTrue("Hard velocity at 0.5 should be <= 0.3f, was $hardVal", hardVal <= 0.3f)

        // Normal curve midpoint
        val normalVal = VelocityMode.NORMAL.calculateVelocity(0.5f)
        assertEquals(0.5f, normalVal, 0.001f)
    }

    @Test
    fun testLearningCurriculum() {
        val lessons = LearningCurriculum.getAllLessons()
        assertTrue("Curriculum should have lessons", lessons.isNotEmpty())

        val beginnerLessons = lessons.filter { it.level == ExperienceLevel.BEGINNER }
        assertTrue("Should have beginner lessons", beginnerLessons.isNotEmpty())

        val intermediateLessons = lessons.filter { it.level == ExperienceLevel.INTERMEDIATE }
        assertTrue("Should have intermediate lessons", intermediateLessons.isNotEmpty())

        // Verify that all lessons have valid steps
        for (lesson in lessons) {
            assertTrue("Lesson ${lesson.id} must have steps", lesson.steps.isNotEmpty())
            assertTrue("Lesson title should not be empty", lesson.title.isNotBlank())
            assertTrue("Lesson amharic title should not be empty", lesson.amharicTitle.isNotBlank())
            for (step in lesson.steps) {
                assertTrue("Step id should not be empty", step.stepId.isNotBlank())
                assertTrue("Step explanation should not be empty", step.explanation.isNotBlank())
                assertTrue("Step amharic explanation should not be empty", step.amharicExplanation.isNotBlank())
            }
        }
    }

    @Test
    fun testLocalizationManager() {
        val supportedLangs = AppLanguage.values()
        assertTrue(supportedLangs.contains(AppLanguage.AMHARIC))
        assertTrue(supportedLangs.contains(AppLanguage.ENGLISH))
        assertTrue(supportedLangs.contains(AppLanguage.AFAAN_OROMOO))
        assertTrue(supportedLangs.contains(AppLanguage.TIGRINYA))

        // Check Amharic translations
        val amharicHome = LocalizationManager.getString("tab_home", AppLanguage.AMHARIC)
        assertEquals("ዋና ገጽ", amharicHome)

        val amharicLearn = LocalizationManager.getString("tab_learn", AppLanguage.AMHARIC)
        assertEquals("ትምህርት", amharicLearn)

        val englishHome = LocalizationManager.getString("tab_home", AppLanguage.ENGLISH)
        assertEquals("Home", englishHome)

        val oromooHome = LocalizationManager.getString("tab_home", AppLanguage.AFAAN_OROMOO)
        assertEquals("Fuula Duraa", oromooHome)
    }

    @Test
    fun testChordDetectorComplexChords() {
        // C minor: C (60), Eb (63), G (67)
        val cm = ChordDetector.detectChord(setOf(60, 63, 67))
        assertNotNull(cm)
        assertEquals("C", cm?.rootName)
        assertEquals(ChordType.MINOR, cm?.type)

        // F Major: F (53), A (57), C (60)
        val fMaj = ChordDetector.detectChord(setOf(53, 57, 60))
        assertNotNull(fMaj)
        assertEquals("F", fMaj?.rootName)
        assertEquals(ChordType.MAJOR, fMaj?.type)
    }
}
