package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.localization.AppLanguage
import com.example.model.ExperienceLevel
import com.example.ui.ConsoleColors

@Composable
fun FirstLaunchDialog(
    initialLevel: ExperienceLevel,
    initialLanguage: AppLanguage,
    initialKeys: Int,
    onComplete: (ExperienceLevel, AppLanguage, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedLevel by remember { mutableStateOf(initialLevel) }
    var selectedLang by remember { mutableStateOf(initialLanguage) }
    var selectedKeys by remember { mutableIntStateOf(initialKeys) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .testTag("first_launch_dialog")
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(12.dp))
                .background(ConsoleColors.ScreenBackground)
                .border(2.dp, ConsoleColors.LedCyan, RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "BIRUK ARRANGER WORKSTATION",
                        color = ConsoleColors.LedCyan,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (selectedLang == AppLanguage.AMHARIC)
                            "እንኳን ወደ ቢሩክ አሬንጀር ኪይቦርድ በደህና መጡ! የአጨዋወት ደረጃዎን ይምረጡ፦"
                        else
                            "Welcome! Choose your experience level and preferences to customize your workstation:",
                        color = ConsoleColors.TextSecondary,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 1. Language Selection Row
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (selectedLang == AppLanguage.AMHARIC) "ቋንቋ ይምረጡ (SELECT LANGUAGE)" else "SELECT LANGUAGE",
                        color = ConsoleColors.LedOrange,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AppLanguage.values().forEach { lang ->
                            val isSel = selectedLang == lang
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) ConsoleColors.LedOrange else Color(0xFF161C28))
                                    .border(1.dp, if (isSel) Color.White else ConsoleColors.ChassisBorder, RoundedCornerShape(6.dp))
                                    .clickable { selectedLang = lang },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = lang.nativeName,
                                    color = if (isSel) Color.Black else ConsoleColors.TextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Experience Level Cards (Beginner, Intermediate, Advanced)
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (selectedLang == AppLanguage.AMHARIC) "የልምድ ደረጃዎን ይምረጡ (CHOOSE EXPERIENCE LEVEL)" else "CHOOSE EXPERIENCE LEVEL",
                        color = ConsoleColors.LedCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExperienceLevel.values().forEach { level ->
                            val isSel = selectedLevel == level
                            val cardBg = when {
                                isSel && level == ExperienceLevel.BEGINNER -> ConsoleColors.LedGreen.copy(alpha = 0.25f)
                                isSel && level == ExperienceLevel.INTERMEDIATE -> ConsoleColors.LedCyan.copy(alpha = 0.25f)
                                isSel && level == ExperienceLevel.ADVANCED -> ConsoleColors.LedOrange.copy(alpha = 0.25f)
                                else -> Color(0xFF131824)
                            }
                            val cardBorder = when {
                                isSel && level == ExperienceLevel.BEGINNER -> ConsoleColors.LedGreen
                                isSel && level == ExperienceLevel.INTERMEDIATE -> ConsoleColors.LedCyan
                                isSel && level == ExperienceLevel.ADVANCED -> ConsoleColors.LedOrange
                                else -> ConsoleColors.ChassisBorder
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(115.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(cardBg)
                                    .border(1.5.dp, cardBorder, RoundedCornerShape(8.dp))
                                    .clickable { selectedLevel = level }
                                    .padding(8.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (selectedLang == AppLanguage.AMHARIC) level.amharicTitle else level.title,
                                            color = if (isSel) Color.White else ConsoleColors.TextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                        if (isSel) {
                                            Text("✓", color = cardBorder, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text(
                                        text = if (selectedLang == AppLanguage.AMHARIC) level.amharicDescription else level.description,
                                        color = ConsoleColors.TextSecondary,
                                        fontSize = 8.5.sp,
                                        lineHeight = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 3. Initial Keyboard Range (Keys)
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (selectedLang == AppLanguage.AMHARIC) "የቁልፎች ብዛት (KEYBOARD RANGE)" else "KEYBOARD RANGE",
                        color = ConsoleColors.LedGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(25, 37, 49, 61, 76, 88).forEach { keys ->
                            val isSel = selectedKeys == keys
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(28.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSel) ConsoleColors.LedGreen else Color(0xFF161C28))
                                    .border(1.dp, if (isSel) Color.White else ConsoleColors.ChassisBorder, RoundedCornerShape(4.dp))
                                    .clickable { selectedKeys = keys },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$keys Keys",
                                    color = if (isSel) Color.Black else ConsoleColors.TextPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF242C3C)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (selectedLang == AppLanguage.AMHARIC) "ዝለል (Skip)" else "Skip Setup",
                            color = ConsoleColors.TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { onComplete(selectedLevel, selectedLang, selectedKeys) },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ConsoleColors.LedCyan),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (selectedLang == AppLanguage.AMHARIC) "ጀምር (Start Playing)" else "Confirm & Start Playing",
                            color = Color.Black,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}
