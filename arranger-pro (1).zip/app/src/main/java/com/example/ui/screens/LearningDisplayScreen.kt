package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.*
import com.example.ui.ConsoleColors

@Composable
fun LearningDisplayScreen(
    currentLesson: Lesson,
    currentStepIndex: Int,
    stepStatus: StepStatus,
    lessonFeedback: String,
    currentLanguage: AppLanguage,
    completedLessonsMap: Map<String, Boolean>,
    onSelectLesson: (Lesson) -> Unit,
    onNextStep: () -> Unit,
    onPrevStep: () -> Unit,
    onRetryStep: () -> Unit
) {
    val currentStep = currentLesson.steps.getOrNull(currentStepIndex) ?: currentLesson.steps.first()
    val isAmharic = currentLanguage == AppLanguage.AMHARIC

    Row(
        modifier = Modifier
            .fillMaxSize()
            .testTag("learning_display_screen"),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // COLUMN 1: Lesson List (Beginner & Intermediate tabs)
        Column(
            modifier = Modifier
                .width(135.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(6.dp))
                .background(ConsoleColors.ScreenCard)
                .border(1.dp, ConsoleColors.ScreenCardBorder, RoundedCornerShape(6.dp))
                .padding(6.dp)
        ) {
            Text(
                text = if (isAmharic) "የትምህርት ዝርዝር" else "LESSON CURRICULUM",
                color = ConsoleColors.LedCyan,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(LearningCurriculum.getAllLessons()) { lesson ->
                    val isCurrent = currentLesson.id == lesson.id
                    val isDone = completedLessonsMap[lesson.id] == true

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (isCurrent) Color(0xFF1F384C) else Color(0xFF131822)
                            )
                            .border(
                                1.dp,
                                if (isCurrent) ConsoleColors.LedCyan else ConsoleColors.ChassisBorder,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { onSelectLesson(lesson) }
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isAmharic) lesson.amharicTitle else "${lesson.number}. ${lesson.title}",
                                    color = if (isCurrent) ConsoleColors.LedCyan else ConsoleColors.TextPrimary,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${lesson.level.title} • ${lesson.steps.size} steps",
                                    color = ConsoleColors.TextDisabled,
                                    fontSize = 6.5.sp
                                )
                            }
                            if (isDone) {
                                Text("★", color = ConsoleColors.LedGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // COLUMN 2: Active Lesson & Step Interactive Guide
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(6.dp))
                .background(ConsoleColors.ScreenCard)
                .border(1.dp, ConsoleColors.ScreenCardBorder, RoundedCornerShape(6.dp))
                .padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAmharic) currentLesson.amharicTitle else currentLesson.title,
                        color = ConsoleColors.TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "STEP ${currentStepIndex + 1} OF ${currentLesson.steps.size}",
                        color = ConsoleColors.LedOrange,
                        fontSize = 8.5.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Step Title & Bilingual Explanation Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF0F1420))
                        .border(1.dp, ConsoleColors.ChassisBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Text(
                            text = if (isAmharic) currentStep.amharicTitle else currentStep.title,
                            color = ConsoleColors.LedCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isAmharic) currentStep.amharicExplanation else currentStep.explanation,
                            color = ConsoleColors.TextPrimary,
                            fontSize = 9.sp,
                            lineHeight = 12.sp
                        )
                        if (currentStep.fingerGuidance.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "👆 " + (if (isAmharic) currentStep.amharicFingerGuidance else currentStep.fingerGuidance),
                                color = ConsoleColors.LedOrange,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Live Interactive Feedback Banner
                val feedbackBg = when (stepStatus) {
                    StepStatus.CORRECT -> Color(0xFF13361E)
                    StepStatus.COMPLETED -> Color(0xFF1C3A50)
                    StepStatus.INCORRECT -> Color(0xFF3A1818)
                    StepStatus.WAITING -> Color(0xFF141A28)
                }
                val feedbackBorder = when (stepStatus) {
                    StepStatus.CORRECT -> ConsoleColors.LedGreen
                    StepStatus.COMPLETED -> ConsoleColors.LedCyan
                    StepStatus.INCORRECT -> ConsoleColors.LedRed
                    StepStatus.WAITING -> ConsoleColors.ChassisBorder
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(feedbackBg)
                        .border(1.dp, feedbackBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    val message = when {
                        lessonFeedback.isNotEmpty() -> lessonFeedback
                        stepStatus == StepStatus.CORRECT -> if (isAmharic) "✓ ትክክል ነው! በጣም ጥሩ!" else "✓ Correct! Well done!"
                        stepStatus == StepStatus.COMPLETED -> if (isAmharic) "★ ትምህርቱን አጠናቀዋል!" else "★ Lesson Completed!"
                        else -> if (isAmharic) "የበሩትን አረንጓዴ ቁልፎች ይጫኑ..." else "Play the glowing green key(s) on the keyboard below..."
                    }
                    Text(
                        text = message,
                        color = when (stepStatus) {
                            StepStatus.CORRECT -> ConsoleColors.LedGreen
                            StepStatus.COMPLETED -> ConsoleColors.LedCyan
                            StepStatus.INCORRECT -> ConsoleColors.LedRed
                            else -> ConsoleColors.TextSecondary
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Step Navigation Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onPrevStep,
                    enabled = currentStepIndex > 0,
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2432)),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(if (isAmharic) "◀ ወደ ኋላ" else "◀ Previous", color = Color.White, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onRetryStep,
                    modifier = Modifier
                        .weight(0.9f)
                        .height(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2432)),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(if (isAmharic) "ደግም (Retry)" else "Retry", color = ConsoleColors.LedOrange, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onNextStep,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(28.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (stepStatus == StepStatus.CORRECT || stepStatus == StepStatus.COMPLETED) ConsoleColors.LedGreen else ConsoleColors.LedCyan
                    ),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    val label = if (currentStepIndex >= currentLesson.steps.size - 1) {
                        if (isAmharic) "ትምህርቱን ጨርስ ★" else "Finish Lesson ★"
                    } else {
                        if (isAmharic) "ቀጣይ እርምጃ ▶" else "Next Step ▶"
                    }
                    Text(label, color = Color.Black, fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        // COLUMN 3: Target Notes & Concept Reference Box
        Column(
            modifier = Modifier
                .width(130.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(6.dp))
                .background(ConsoleColors.ScreenCard)
                .border(1.dp, ConsoleColors.ScreenCardBorder, RoundedCornerShape(6.dp))
                .padding(6.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = if (isAmharic) "ዒላማ ኖታዎች" else "TARGET KEYS",
                    color = ConsoleColors.TextSecondary,
                    fontSize = 7.5.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF0F1420))
                        .border(1.dp, ConsoleColors.LedGreen.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (currentStep.targetChordSymbol != null) {
                                "${currentStep.targetChordSymbol} CHORD"
                            } else if (currentStep.targetMidiNotes.isNotEmpty()) {
                                currentStep.targetMidiNotes.joinToString(" • ") { midi ->
                                    val name = ChordInfo.NOTE_NAMES[midi % 12]
                                    val oct = (midi / 12) - 1
                                    "$name$oct"
                                }
                            } else if (currentStep.targetButtonName != null) {
                                currentStep.targetButtonName
                            } else {
                                "EXPLORE"
                            },
                            color = ConsoleColors.LedGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isAmharic) "ጠቃሚ ምክር" else "KEY TIP",
                    color = ConsoleColors.TextSecondary,
                    fontSize = 7.5.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isAmharic)
                        "በኪይቦርዱ ላይ አረንጓዴ የሚያበሩት ቁልፎች የትምህርቱ ዒላማዎች ናቸው። ጣትዎን በትክክለኛው ቁልፍ ላይ ያሳርፉ።"
                    else
                        "The keys glowing green on the bottom keyboard indicate your targets. Place your fingers accordingly.",
                    color = ConsoleColors.TextDisabled,
                    fontSize = 7.sp,
                    lineHeight = 10.sp
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF131924))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "BIRUK ARRANGER LEARN",
                    color = ConsoleColors.LedCyan,
                    fontSize = 6.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
