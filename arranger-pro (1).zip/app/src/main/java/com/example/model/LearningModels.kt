package com.example.model

enum class StepTargetType {
    NOTE_TOUCH,
    CHORD_PLAY,
    BUTTON_PRESS,
    READ_AND_EXPLORE
}

enum class StepStatus {
    WAITING,
    CORRECT,
    INCORRECT,
    COMPLETED
}

data class LessonStep(
    val stepId: String,
    val title: String,
    val amharicTitle: String,
    val explanation: String,
    val amharicExplanation: String,
    val targetType: StepTargetType = StepTargetType.NOTE_TOUCH,
    val targetMidiNotes: Set<Int> = emptySet(),
    val targetChordSymbol: String? = null,
    val targetButtonName: String? = null,
    val highlightNotes: Set<Int> = emptySet(),
    val fingerGuidance: String = "",
    val amharicFingerGuidance: String = ""
)

data class Lesson(
    val id: String,
    val level: ExperienceLevel,
    val number: Int,
    val title: String,
    val amharicTitle: String,
    val summary: String,
    val amharicSummary: String,
    val steps: List<LessonStep>
)

object LearningCurriculum {

    val BEGINNER_LESSONS: List<Lesson> = listOf(
        Lesson(
            id = "beg_1",
            level = ExperienceLevel.BEGINNER,
            number = 1,
            title = "White Keys & The C Scale",
            amharicTitle = "ትምህርት 1፡ የፒያኖ ነጭ ቁልፎች እና የ C ኖታዎች",
            summary = "Learn the 7 musical letters: C, D, E, F, G, A, B. Understand how they repeat across the keyboard.",
            amharicSummary = "7ቱን የሙዚቃ ፊደላት (C, D, E, F, G, A, B) እና በኪይቦርድ ላይ እንዴት እንደሚደጋገሙ ይማሩ።",
            steps = listOf(
                LessonStep(
                    stepId = "beg_1_step_1",
                    title = "Find Middle C (C4)",
                    amharicTitle = "መካከለኛ ሲ (C4) ማግኘት",
                    explanation = "Look for the group of TWO black keys in the center. The white key immediately to the left is C (Middle C / C4). Touch it now!",
                    amharicExplanation = "በመሃል ያሉትን የሁለቱን ጥቁር ቁልፎች ጥንድ ይመልከቱ። ከሁለቱ ጥቁር ቁልፎች በስተግራ በኩል ያለው ነጭ ቁልፍ 'C' (መካከለኛ C4) ይባላል። አሁኑኑ ንኩት!",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(60),
                    highlightNotes = setOf(60),
                    fingerGuidance = "Right Hand: Finger 1 (Thumb)",
                    amharicFingerGuidance = "የቀኝ እጅ፡ አውራ ጣት (ቁጥር 1)"
                ),
                LessonStep(
                    stepId = "beg_1_step_2",
                    title = "Play D (Re)",
                    amharicTitle = "ዲ (D) ቁልፍን ይጫወቱ",
                    explanation = "D is located right between the two black keys. Touch D4 next to C.",
                    amharicExplanation = "D የሚገኘው በሁለቱ ጥቁር ቁልፎች መሃከል ነው። ከ C ቀጥሎ ያለውን D4 ቁልፍ ይንኩ።",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(62),
                    highlightNotes = setOf(62),
                    fingerGuidance = "Right Hand: Finger 2 (Index)",
                    amharicFingerGuidance = "የቀኝ እጅ፡ አመልካች ጣት (ቁጥር 2)"
                ),
                LessonStep(
                    stepId = "beg_1_step_3",
                    title = "Play E (Mi)",
                    amharicTitle = "ኢ (E) ቁልፍን ይጫወቱ",
                    explanation = "E is the white key to the right of the two black keys. Touch E4.",
                    amharicExplanation = "E ከሁለቱ ጥቁር ቁልፎች በስተቀኝ በኩል የሚገኘው ነጭ ቁልፍ ነው። E4 ን ይንኩ።",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(64),
                    highlightNotes = setOf(64),
                    fingerGuidance = "Right Hand: Finger 3 (Middle)",
                    amharicFingerGuidance = "የቀኝ እጅ፡ የመሃል ጣት (ቁጥር 3)"
                ),
                LessonStep(
                    stepId = "beg_1_step_4",
                    title = "Play C - D - E in Succession",
                    amharicTitle = "C - D - E በተከታታይ ይጫወቱ",
                    explanation = "Now play C, then D, then E smoothly in ascending order.",
                    amharicExplanation = "አሁን C፣ ቀጥሎ D፣ ቀጥሎ E በተከታታይ በቅደም ተከተል ይጫወቱ።",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(60, 62, 64),
                    highlightNotes = setOf(60, 62, 64),
                    fingerGuidance = "Right Hand: Fingers 1, 2, 3",
                    amharicFingerGuidance = "የቀኝ እጅ ጣቶች፡ 1፣ 2፣ 3"
                ),
                LessonStep(
                    stepId = "beg_1_step_5",
                    title = "The 3 Black Keys Group: F, G, A, B",
                    amharicTitle = "የ3ቱ ጥቁር ቁልፎች ቡድን፡ F, G, A, B",
                    explanation = "Next look at the group of THREE black keys. The white key to the left of them is F (F4). Touch F4!",
                    amharicExplanation = "ቀጥሎ ያሉትን የሶስቱን ጥቁር ቁልፎች ቡድን ይመልከቱ። ከሶስቱ ጥቁር ቁልፎች በስተግራ ያለው ነጭ ቁልፍ F ይባላል። F4 ን ይንኩ!",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(65),
                    highlightNotes = setOf(65),
                    fingerGuidance = "Right Hand: Finger 1 (Thumb)",
                    amharicFingerGuidance = "የቀኝ እጅ፡ አውራ ጣት"
                )
            )
        ),
        Lesson(
            id = "beg_2",
            level = ExperienceLevel.BEGINNER,
            number = 2,
            title = "Black Keys, Sharps (#) & Flats (b)",
            amharicTitle = "ትምህርት 2፡ ጥቁር ቁልፎች፣ ሻርፕ (#) እና ፍላት (b)",
            summary = "Understand accidentals: how black keys raise notes by a half-step (sharp) or lower them (flat).",
            amharicSummary = "ጥቁር ቁልፎች የኖታዎችን ድምፅ በግማሽ ደረጃ ከፍ (ሻርፕ #) ወይም ዝቅ (ፍላት b) የሚያደርጉ መሆናቸውን ይማሩ።",
            steps = listOf(
                LessonStep(
                    stepId = "beg_2_step_1",
                    title = "Find C# (C Sharp) / Db (D Flat)",
                    amharicTitle = "C# (C ሻርፕ) ማግኘት",
                    explanation = "C# is the first black key of the two-black-key group, directly right of C. Touch it!",
                    amharicExplanation = "C# ከ C ነጭ ቁልፍ ቀጥሎ በስተቀኝ ያለው የመጀመሪያው ጥቁር ቁልፍ ነው። ይንኩት!",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(61),
                    highlightNotes = setOf(61),
                    fingerGuidance = "Finger 2 or 3",
                    amharicFingerGuidance = "አመልካች ወይም የመሃል ጣት"
                ),
                LessonStep(
                    stepId = "beg_2_step_2",
                    title = "Find F# (F Sharp)",
                    amharicTitle = "F# (F ሻርፕ) ማግኘት",
                    explanation = "F# is the first black key in the three-black-key group, directly right of F. Touch it!",
                    amharicExplanation = "F# በሶስቱ ጥቁር ቁልፎች ቡድን ውስጥ የመጀመሪያው ጥቁር ቁልፍ ነው። ይንኩት!",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(66),
                    highlightNotes = setOf(66),
                    fingerGuidance = "Finger 2 or 3",
                    amharicFingerGuidance = "አመልካች ወይም የመሃል ጣት"
                ),
                LessonStep(
                    stepId = "beg_2_step_3",
                    title = "Find Bb (B Flat) / A#",
                    amharicTitle = "Bb (B ፍላት) ማግኘት",
                    explanation = "Bb is the last black key in the three-black-key group, directly left of B. Touch it!",
                    amharicExplanation = "Bb በሶስቱ ጥቁር ቁልፎች ቡድን ውስጥ የመጨረሻው ጥቁር ቁልፍ ነው። ይንኩት!",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(70),
                    highlightNotes = setOf(70),
                    fingerGuidance = "Finger 3 or 4",
                    amharicFingerGuidance = "የመሃል ወይም የቀለበት ጣት"
                )
            )
        ),
        Lesson(
            id = "beg_3",
            level = ExperienceLevel.BEGINNER,
            number = 3,
            title = "C Major Chord (C - E - G)",
            amharicTitle = "ትምህርት 3፡ የ C ሜጀር ኮርድ (C - E - G)",
            summary = "Master your first chord! Press C, E, and G together to produce a rich, harmonious sound.",
            amharicSummary = "የመጀመሪያዎን ኮርድ ይማሩ! C, E እና G ቁልፎችን በአንድ ላይ በመጫን አስደሳችና ሙሉ ስምም ድምፅ ይፍጠሩ።",
            steps = listOf(
                LessonStep(
                    stepId = "beg_3_step_1",
                    title = "Play C Major Triad (C - E - G)",
                    amharicTitle = "የ C ሜጀር ኮርድን በአንድነት ይጫወቱ",
                    explanation = "Place your fingers on C, E, and G. Press all three keys down at the SAME TIME!",
                    amharicExplanation = "ጣቶችዎን C፣ E እና G ላይ ያሳርፉ። ሦስቱንም ቁልፎች በአንድ ጊዜ ይጫኑ!",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "C",
                    targetMidiNotes = setOf(60, 64, 67),
                    highlightNotes = setOf(60, 64, 67),
                    fingerGuidance = "Right Hand: Finger 1 (C), Finger 3 (E), Finger 5 (G)",
                    amharicFingerGuidance = "የቀኝ እጅ፡ ጣት 1 (C)፣ ጣት 3 (E)፣ ጣት 5 (G)"
                ),
                LessonStep(
                    stepId = "beg_3_step_2",
                    title = "Left Hand C Major Bass Chord",
                    amharicTitle = "በግራ እጅ የ C ሜጀር ኮርድን መጫወት",
                    explanation = "On arranger keyboards, your LEFT hand plays chords below Middle C to drive the backing band. Play C3 + E3 + G3 in the left zone!",
                    amharicExplanation = "በአሬንጀር ኪይቦርዶች ላይ ግራ እጅዎ ከመካከለኛው C በታች ኮርዶችን በመጫወት አጃቢውን ሙዚቃ ይመራል። በግራ እጅዎ C3, E3, G3 ን ይጫወቱ!",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "C",
                    targetMidiNotes = setOf(48, 52, 55),
                    highlightNotes = setOf(48, 52, 55),
                    fingerGuidance = "Left Hand: Finger 5 (C), Finger 3 (E), Finger 1 (G)",
                    amharicFingerGuidance = "የግራ እጅ፡ ጣት 5 (C)፣ ጣት 3 (E)፣ ጣት 1 (G)"
                )
            )
        ),
        Lesson(
            id = "beg_4",
            level = ExperienceLevel.BEGINNER,
            number = 4,
            title = "A Minor & G Major Chords",
            amharicTitle = "ትምህርት 4፡ ኤ ማይነር (Am) እና ጂ ሜጀር (G) ኮርዶች",
            summary = "Expand your harmonic vocabulary with A Minor (A-C-E) and G Major (G-B-D).",
            amharicSummary = "የኮርድ እውቀትዎን ያዳብሩ፡ ኤ ማይነር (A-C-E) እና ጂ ሜጀር (G-B-D) ቁልፎችን ይማሩ።",
            steps = listOf(
                LessonStep(
                    stepId = "beg_4_step_1",
                    title = "Play A Minor Chord (A - C - E)",
                    amharicTitle = "ኤ ማይነር (Am) ኮርድ ይጫወቱ",
                    explanation = "Press A, C, and E together. Notice the softer, more emotional quality of the minor chord.",
                    amharicExplanation = "A, C እና E ቁልፎችን በአንድ ላይ ይጫኑ። የማይነር ኮርድ ያለውን ስሜታዊ ድምፅ ያስተውሉ።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "Am",
                    targetMidiNotes = setOf(57, 60, 64),
                    highlightNotes = setOf(57, 60, 64),
                    fingerGuidance = "Finger 1 (A), Finger 2/3 (C), Finger 5 (E)",
                    amharicFingerGuidance = "ጣት 1 (A)፣ ጣት 2/3 (C)፣ ጣት 5 (E)"
                ),
                LessonStep(
                    stepId = "beg_4_step_2",
                    title = "Play G Major Chord (G - B - D)",
                    amharicTitle = "ጂ ሜጀር (G) ኮርድ ይጫወቱ",
                    explanation = "Press G, B, and D together. This creates a bright, energetic harmony.",
                    amharicExplanation = "G, B እና D ቁልፎችን በአንድ ላይ ይጫኑ። ይህ ብሩህና ህያው የሆነ የድምፅ ስምምነት ይፈጥራል።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "G",
                    targetMidiNotes = setOf(55, 59, 62),
                    highlightNotes = setOf(55, 59, 62),
                    fingerGuidance = "Finger 1 (G), Finger 3 (B), Finger 5 (D)",
                    amharicFingerGuidance = "ጣት 1 (G)፣ ጣት 3 (B)፣ ጣት 5 (D)"
                )
            )
        ),
        Lesson(
            id = "beg_5",
            level = ExperienceLevel.BEGINNER,
            number = 5,
            title = "Arranger Basics: Intro, Main, Fill & Ending",
            amharicTitle = "ትምህርት 5፡ የአሬንጀር ክፍሎች፡ ኢንትሮ፣ ሜይን፣ ፊል እና ኤንዲንግ",
            summary = "Learn how real hardware arrangers structure songs: Intro, Main variation, drum fills, and final ending.",
            amharicSummary = "የአሬንጀር ኪይቦርድ ሙዚቃን እንዴት እንደሚያቀናጅ ይማሩ፡ መግቢያ (Intro)፣ ዋና ሪትም (Main)፣ የከበሮ ፊል (Fill) እና መዝጊያ (Ending)።",
            steps = listOf(
                LessonStep(
                    stepId = "beg_5_step_1",
                    title = "Start the Arranger with START / STOP",
                    amharicTitle = "START/STOP በመንካት አሬንጀሩን ያስጀምሩ",
                    explanation = "Press the large START / STOP button on the left panel to start the live rhythm drum track.",
                    amharicExplanation = "በግራ በኩል ያለውን ትልቅ START / STOP ቁልፍ በመንካት የከበሮውን ሪትም ያስጀምሩ።",
                    targetType = StepTargetType.BUTTON_PRESS,
                    targetButtonName = "START_STOP",
                    fingerGuidance = "Press START / STOP button",
                    amharicFingerGuidance = "START/STOP ቁልፍን ይጫኑ"
                ),
                LessonStep(
                    stepId = "beg_5_step_2",
                    title = "Trigger a Drum Fill-In (FILL)",
                    amharicTitle = "የከበሮ ፊል (FILL) ይጫኑ",
                    explanation = "During a song, a Drum Fill transitions between musical phrases. Press the FILL button now!",
                    amharicExplanation = "በሙዚቃ መሃል የከበሮ ፊል (Fill) ከአንዱ ክፍል ወደ ሌላው ለመሸጋገር ያገለግላል። የ FILL ቁልፍን ይጫኑ!",
                    targetType = StepTargetType.BUTTON_PRESS,
                    targetButtonName = "FILL_IN",
                    fingerGuidance = "Press FILL button",
                    amharicFingerGuidance = "FILL ቁልፍን ይጫኑ"
                ),
                LessonStep(
                    stepId = "beg_5_step_3",
                    title = "Conclude the Song with ENDING",
                    amharicTitle = "ዘፈኑን በ ENDING ይጨርሱ",
                    explanation = "Press the ENDING button. Notice how the arranger plays an automatic musical conclusion and comes to a complete halt.",
                    amharicExplanation = "የ ENDING ቁልፍን ይጫኑ። አሬንጀሩ ዘፈኑን በስርአት አጠናቆ ራሱን እንደሚያቆም ይመልከቱ።",
                    targetType = StepTargetType.BUTTON_PRESS,
                    targetButtonName = "ENDING",
                    fingerGuidance = "Press ENDING button",
                    amharicFingerGuidance = "ENDING ቁልፍን ይጫኑ"
                )
            )
        )
    )

    val INTERMEDIATE_LESSONS: List<Lesson> = listOf(
        Lesson(
            id = "int_1",
            level = ExperienceLevel.INTERMEDIATE,
            number = 1,
            title = "The 4-Chord Progression (C - G - Am - F)",
            amharicTitle = "የ 4-ኮርድ ቅደም ተከተል (C - G - Am - F)",
            summary = "The legendary pop progression used in hundreds of hit songs. Practice smooth chord transitions.",
            amharicSummary = "በመቶዎች በሚቆጠሩ ታዋቂ ዘፈኖች ውስጥ ጥቅም ላይ የሚውለው የ C - G - Am - F ኮርድ ቅደም ተከተልን ይለማመዱ።",
            steps = listOf(
                LessonStep(
                    stepId = "int_1_step_1",
                    title = "Chord 1: C Major",
                    amharicTitle = "ኮርድ 1፡ C ሜጀር",
                    explanation = "Play C Major in the left hand to set the key center.",
                    amharicExplanation = "በግራ እጅዎ C ሜጀርን ይጫወቱ።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "C",
                    targetMidiNotes = setOf(48, 52, 55),
                    highlightNotes = setOf(48, 52, 55)
                ),
                LessonStep(
                    stepId = "int_1_step_2",
                    title = "Chord 2: G Major",
                    amharicTitle = "ኮርድ 2፡ G ሜጀር",
                    explanation = "Shift smoothly to G Major (G - B - D).",
                    amharicExplanation = "ወደ G ሜጀር (G - B - D) በተረጋጋ ሁኔታ ይሸጋገሩ።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "G",
                    targetMidiNotes = setOf(43, 47, 50),
                    highlightNotes = setOf(43, 47, 50)
                ),
                LessonStep(
                    stepId = "int_1_step_3",
                    title = "Chord 3: A Minor",
                    amharicTitle = "ኮርድ 3፡ A ማይነር (Am)",
                    explanation = "Shift to A Minor (A - C - E).",
                    amharicExplanation = "ወደ A ማይነር (A - C - E) ይሸጋገሩ።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "Am",
                    targetMidiNotes = setOf(45, 48, 52),
                    highlightNotes = setOf(45, 48, 52)
                ),
                LessonStep(
                    stepId = "int_1_step_4",
                    title = "Chord 4: F Major",
                    amharicTitle = "ኮርድ 4፡ F ሜጀር",
                    explanation = "Resolve with F Major (F - A - C).",
                    amharicExplanation = "በ F ሜጀር (F - A - C) ይደመድሙ።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "F",
                    targetMidiNotes = setOf(41, 45, 48),
                    highlightNotes = setOf(41, 45, 48)
                )
            )
        ),
        Lesson(
            id = "int_2",
            level = ExperienceLevel.INTERMEDIATE,
            number = 2,
            title = "Two-Hand Performance with Arranger Backing",
            amharicTitle = "በሁለት እጅ ከአጃቢ ባንድ ጋር መጫወት",
            summary = "Hold chords in your left hand while playing a melody on the right side of the split point.",
            amharicSummary = "በግራ እጅዎ ኮርድ ይዘው በቀኝ እጅዎ ዜማ (Melody) በስፕሊት ነጥቡ ማዶ መጫወትን ይለማመዱ።",
            steps = listOf(
                LessonStep(
                    stepId = "int_2_step_1",
                    title = "Hold Left-Hand C Chord",
                    amharicTitle = "የግራ እጅ C ኮርድን ይያዙ",
                    explanation = "Press and hold C Major with your left hand in the lower octave.",
                    amharicExplanation = "በግራ እጅዎ የ C ሜጀር ኮርድን በዝቅተኛው ኦክታቭ ይጫኑ።",
                    targetType = StepTargetType.CHORD_PLAY,
                    targetChordSymbol = "C",
                    targetMidiNotes = setOf(48, 52, 55),
                    highlightNotes = setOf(48, 52, 55)
                ),
                LessonStep(
                    stepId = "int_2_step_2",
                    title = "Play Right-Hand Melody Notes: G4 -> E4 -> C4",
                    amharicTitle = "የቀኝ እጅ ዜማ ኖታዎችን ይጫወቱ፡ G4 -> E4 -> C4",
                    explanation = "Now play the melody notes G4, E4, and C4 in the right hand zone.",
                    amharicExplanation = "አሁን በቀኝ እጅዎ G4፣ E4 እና C4 ኖታዎችን ይጫወቱ።",
                    targetType = StepTargetType.NOTE_TOUCH,
                    targetMidiNotes = setOf(67, 64, 60),
                    highlightNotes = setOf(67, 64, 60)
                )
            )
        )
    )

    fun getAllLessons(): List<Lesson> = BEGINNER_LESSONS + INTERMEDIATE_LESSONS

    fun getLessonById(id: String): Lesson? = getAllLessons().firstOrNull { it.id == id }
}
