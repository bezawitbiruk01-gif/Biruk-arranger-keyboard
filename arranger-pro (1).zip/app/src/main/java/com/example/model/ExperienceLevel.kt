package com.example.model

enum class ExperienceLevel(
    val title: String,
    val amharicTitle: String,
    val description: String,
    val amharicDescription: String
) {
    BEGINNER(
        title = "Beginner",
        amharicTitle = "ጀማሪ",
        description = "Step-by-step interactive lessons from scratch: white & black keys, note names, C position, chords, and guided practice.",
        amharicDescription = "ከዜሮ የሚጀምር በይነተገናኝ ትምህርት፡ የነጭና ጥቁር ቁልፎች፣ የኖታ ስሞች፣ ሲ-ቦታ፣ ኮርዶች እና መመሪያዎች።"
    ),
    INTERMEDIATE(
        title = "Intermediate",
        amharicTitle = "መካከለኛ",
        description = "Arranger keyboard mastery: chord accompaniment, splits, layers, variations, registrations, and rhythm timing.",
        amharicDescription = "የአሬንጀር ኪይቦርድ አጨዋወት፡ የግራ እጅ ኮርድ ቅንብር፣ ስፕሊት፣ ሌየር፣ የሪትም ልዩነቶች እና ሬጅስትሬሽን።"
    ),
    ADVANCED(
        title = "Advanced",
        amharicTitle = "ከፍተኛ / ፕሮፌሽናል",
        description = "Full professional workstation console: multi-part mixer, DSP effects, multi-pads, deep sound editing, and live performance.",
        amharicDescription = "ሙሉ የፕሮፌሽናል ኮንሶል፡ ሚክሰር፣ ዲኤስፒ ኢፌክቶች፣ መልቲ-ፓድስ፣ ጥልቅ ድምፅ ማስተካከያ እና የቀጥታ አጨዋወት።"
    )
}

enum class VelocityMode(
    val title: String,
    val amharicTitle: String,
    val description: String
) {
    NORMAL("Normal", "መደበኛ", "Dynamic response based on touch position / speed"),
    SOFT("Soft Touch", "ለስላሳ ንክኪ", "Louder sound even with light touch"),
    HARD("Hard Touch", "ጠንካራ ንክኪ", "Wide dynamic range requiring firm touch"),
    FIXED_FULL("Fixed 100%", "ቋሚ ሙሉ (100%)", "Constant maximum loudness (1.0f) for every touch");

    fun calculateVelocity(rawVelocity: Float): Float {
        return when (this) {
            NORMAL -> rawVelocity.coerceIn(0.2f, 1.0f)
            SOFT -> (0.5f + rawVelocity * 0.5f).coerceIn(0.5f, 1.0f)
            HARD -> (rawVelocity * rawVelocity).coerceIn(0.1f, 1.0f)
            FIXED_FULL -> 1.0f
        }
    }
}
