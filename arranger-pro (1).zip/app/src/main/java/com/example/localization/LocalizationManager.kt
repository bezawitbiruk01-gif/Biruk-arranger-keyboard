package com.example.localization

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    AMHARIC("am", "Amharic", "አማርኛ"),
    ENGLISH("en", "English", "English"),
    AFAAN_OROMOO("om", "Afaan Oromoo", "Afaan Oromoo"),
    TIGRINYA("ti", "Tigrinya", "ትግርኛ"),
    SOMALI("so", "Somali", "Soomaali"),
    SIDAMA("sid", "Sidama", "Sidaamu Afoo")
}

object LocalizationManager {

    private val translations = mapOf(
        "app_title" to mapOf(
            AppLanguage.ENGLISH to "Biruk Arranger Workstation",
            AppLanguage.AMHARIC to "ቢሩክ አሬንጀር ዎርክስቴሽን",
            AppLanguage.AFAAN_OROMOO to "Biruk Arranger Workstation",
            AppLanguage.TIGRINYA to "ቢሩክ አሬንጀር ዎርክስቴሽን",
            AppLanguage.SOMALI to "Biruk Arranger Workstation",
            AppLanguage.SIDAMA to "Biruk Arranger Workstation"
        ),
        "tab_home" to mapOf(
            AppLanguage.ENGLISH to "Home",
            AppLanguage.AMHARIC to "ዋና ገጽ",
            AppLanguage.AFAAN_OROMOO to "Fuula Duraa",
            AppLanguage.TIGRINYA to "ቀንዲ ገጽ",
            AppLanguage.SOMALI to "Bogga Hore",
            AppLanguage.SIDAMA to "Hanafo"
        ),
        "tab_voice" to mapOf(
            AppLanguage.ENGLISH to "Voice",
            AppLanguage.AMHARIC to "የመሳሪያ ድምፅ",
            AppLanguage.AFAAN_OROMOO to "Sagalee Meeshaa",
            AppLanguage.TIGRINYA to "ድምጺ መሳርሒ",
            AppLanguage.SOMALI to "Codka Qalabka",
            AppLanguage.SIDAMA to "Uurrinshate Huuro"
        ),
        "tab_style" to mapOf(
            AppLanguage.ENGLISH to "Style",
            AppLanguage.AMHARIC to "ሪትም / ስታይል",
            AppLanguage.AFAAN_OROMOO to "Akkaata Ritimii",
            AppLanguage.TIGRINYA to "ስልቲ / ሪትም",
            AppLanguage.SOMALI to "Qaabka Laxanka",
            AppLanguage.SIDAMA to "Ritimete Danicho"
        ),
        "tab_learn" to mapOf(
            AppLanguage.ENGLISH to "Learn",
            AppLanguage.AMHARIC to "ትምህርት",
            AppLanguage.AFAAN_OROMOO to "Baradhu",
            AppLanguage.TIGRINYA to "ተምሃር",
            AppLanguage.SOMALI to "Baro",
            AppLanguage.SIDAMA to "Rosi"
        ),
        "tab_song" to mapOf(
            AppLanguage.ENGLISH to "Song",
            AppLanguage.AMHARIC to "ቅጂ / መዝገብ",
            AppLanguage.AFAAN_OROMOO to "Sirba",
            AppLanguage.TIGRINYA to "መዝገብ ደርፊ",
            AppLanguage.SOMALI to "Hees",
            AppLanguage.SIDAMA to "Faarso"
        ),
        "tab_mixer" to mapOf(
            AppLanguage.ENGLISH to "Mixer",
            AppLanguage.AMHARIC to "ሚክሰር",
            AppLanguage.AFAAN_OROMOO to "Miksarii",
            AppLanguage.TIGRINYA to "ሚክሰር",
            AppLanguage.SOMALI to "Isku-dhafiye",
            AppLanguage.SIDAMA to "Miksere"
        ),
        "tab_effects" to mapOf(
            AppLanguage.ENGLISH to "DSP Effects",
            AppLanguage.AMHARIC to "ድምፅ ማስተካከያ (ኢፌክቶች)",
            AppLanguage.AFAAN_OROMOO to "Ifeektii Sagalee",
            AppLanguage.TIGRINYA to "ኢፌክት ድምጺ",
            AppLanguage.SOMALI to "Saamaynta Codka",
            AppLanguage.SIDAMA to "Huurote Dhibba"
        ),
        "tab_registration" to mapOf(
            AppLanguage.ENGLISH to "Registration",
            AppLanguage.AMHARIC to "ሬጅስትሬሽን ማከማቻ",
            AppLanguage.AFAAN_OROMOO to "Kuusaa Qophii",
            AppLanguage.TIGRINYA to "መዝገብ ምድላው",
            AppLanguage.SOMALI to "Diiwaangelin",
            AppLanguage.SIDAMA to "Kuusu Kaa'lo"
        ),
        "tab_settings" to mapOf(
            AppLanguage.ENGLISH to "Settings",
            AppLanguage.AMHARIC to "ቅንብሮች",
            AppLanguage.AFAAN_OROMOO to "Qindaa'ina",
            AppLanguage.TIGRINYA to "ቅጥዕታት",
            AppLanguage.SOMALI to "Hagaajinta",
            AppLanguage.SIDAMA to "Qinaasanno"
        ),
        "split_explanation" to mapOf(
            AppLanguage.ENGLISH to "Split divides the keyboard into left hand (chords/accompaniment) and right hand (melody).",
            AppLanguage.AMHARIC to "ስፕሊት (Split) ማለት የኪይቦርድ ቁልፎችን ለሁለት ከፍሎ በግራ እጅ ኮርድ/አጃቢ፣ በቀኝ እጅ ደግሞ ዜማ ለመጫወት የሚያስችል ነው።",
            AppLanguage.AFAAN_OROMOO to "Split jechuun furtuuwwan kiiyboordii bakka lamatti qooduun harka bitaatiin koordii, mirgaatiin immoo sirba taphachuudha.",
            AppLanguage.TIGRINYA to "ስፕሊት ማለት ንመፋተሕ ኪቦርድ ኣብ ክልተ መቒልካ ብጸጋም ኢድካ ኮርድ/መሰነይታ ብየማን ኢድካ ዜማ ንምጽዋት ዘኽእል እዩ።",
            AppLanguage.SOMALI to "Split waxay u qaybisaa furayaasha laba dhinac: gacanta bidix ee koordka iyo gacanta midig ee laxanka.",
            AppLanguage.SIDAMA to "Split yaannohu kiiboordete qulfe lamente garinni qoodatenni gurchu anganni kordene qiniitenni zema yannaati."
        ),
        "layer_explanation" to mapOf(
            AppLanguage.ENGLISH to "Layer (Dual) blends two sounds together simultaneously when pressing keys (e.g., Piano + Strings).",
            AppLanguage.AMHARIC to "ሌየር (Layer) ማለት ሁለት የተለያዩ የሙዚቃ መሳሪያ ድምፆችን በአንድነት አጣምሮ የሚያሰማ ነው (ለምሳሌ፡ ፒያኖ ከቫዮሊን/ስትሪንግስ ጋር)።",
            AppLanguage.AFAAN_OROMOO to "Layer jechuun sagalee meeshaalee lama yeroo tokkotti walitti makuun taphachuudha (fakkeenyaaf Piyoanoo fi Istiriingii).",
            AppLanguage.TIGRINYA to "ሌየር ማለት ክልተ ዝተፈላለዩ ድምጽታት መሳርሒታት ብሓደ ግዜ ኣወሃሂድካ ዘስምዕ እዩ (ንኣብነት ፒያኖ ምስ ስትሪንግስ)።",
            AppLanguage.SOMALI to "Layer waxay isku daraysaa laba cod isku mar marka furayaasha la riixo (tusaale, Piano iyo Strings).",
            AppLanguage.SIDAMA to "Layer yaannohu lame huuro mittimma qolate (lawishshaho Piyano nna Istringe)."
        ),
        "acmp_explanation" to mapOf(
            AppLanguage.ENGLISH to "ACMP (Accompaniment) automatically generates full band rhythms, basslines, and harmonies matching your left-hand chords.",
            AppLanguage.AMHARIC to "አክምፕ (ACMP) በግራ እጅ የሚጫወቱትን ኮርድ ተከትሎ ሙሉ ባንድ (ከበሮ፣ ባስ እና ሪትም) በራሱ አቀናጅቶ የሚያሰማ አጃቢ ነው።",
            AppLanguage.AFAAN_OROMOO to "ACMP jechuun koordii harka bitaa hordofuun ritimii, baasii fi muuziqaa guutuu ofumaan kan uumudha.",
            AppLanguage.TIGRINYA to "ኤሲኤምፒ (ACMP) ንዝተጻወትካዮ ኮርድ ተኸቲሉ ምሉእ ባንድ (ከበሮ፣ ባስን ሪትምን) ብባዕሉ ዘሰንይ እዩ።",
            AppLanguage.SOMALI to "ACMP waxay si toos ah u abuurtaa durbaanka, baaska iyo laxanka oo la socda gacantaada bidix.",
            AppLanguage.SIDAMA to "ACMP gurchu anganni ganooto kordi garinni wo'ma baande ofollanno garooti."
        )
    )

    fun getString(key: String, language: AppLanguage): String {
        val keyMap = translations[key] ?: return key
        return keyMap[language]
            ?: keyMap[AppLanguage.AMHARIC]
            ?: keyMap[AppLanguage.ENGLISH]
            ?: key
    }
}
